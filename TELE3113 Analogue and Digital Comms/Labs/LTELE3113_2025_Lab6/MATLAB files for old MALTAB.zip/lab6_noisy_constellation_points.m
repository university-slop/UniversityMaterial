% Define the number of bits per symbol for QPSK modulation (2 bits per symbol)
bits_per_symbol = 2; 

% Generate the QPSK constellation points. These are evenly spaced on the unit circle at angles pi/4, 3pi/4, 5pi/4, and 7pi/4.
constellation = constellation = ...; % Define a vector of complex exponentials as shown in the lab manual; exp(1j*theta_k)

% Simulate transmitted symbols by randomly selecting indices from the constellation points.
% randi([1, length(constellation)], 1, 1000) generates 1000 random integers between 1 and the length of the constellation.
modulated_symbols = constellation(randi([1, length(constellation)], 1, 1000));

% Define the Signal-to-Noise Ratio (SNR) in dB. This is an example value for simulation.
SNR_dB = 15; 

% Convert the SNR from dB to linear scale using the formula: SNR_linear = 10^(SNR_dB / 10).
SNR_linear = 10^(SNR_dB / 10); 

% Calculate the noise standard deviation (sigma) based on the SNR in linear scale.
% The formula for sigma is sqrt(1 / SNR_linear), assuming unit signal energy; Es=1.
sigma = sqrt(1 / SNR_linear); 

% Generate AWGN (Additive White Gaussian Noise) with zero mean and variance sigma^2.
% The noise is complex-valued, with real and imaginary parts being independent Gaussian random variables.
noise = (sigma / sqrt(2)) * (randn(size(modulated_symbols)) + 1j * randn(size(modulated_symbols)));

% Add the generated noise to the transmitted symbols to simulate the received symbols.
received_symbols = modulated_symbols + noise;

% Create a new figure for plotting.
figure;

% Enable hold on to overlay multiple plots on the same figure.
hold on;

% Plot the original QPSK constellation points as blue circles with filled markers.
% These represent the ideal transmitted symbols without noise.
plot(real(constellation), imag(constellation), 'bo', 'MarkerFaceColor', 'b', 'MarkerSize', 8, 'DisplayName', 'Original Constellation');

% Plot the noisy received symbols as red dots.
% These represent the transmitted symbols after being distorted by AWGN.
plot(real(received_symbols), imag(received_symbols), 'r.', 'MarkerSize', 4, 'DisplayName', 'Noisy Received Symbols');

% Label the x-axis as "In-Phase (Real)" to indicate the real part of the complex symbols.
xlabel('In-Phase (Real)');

% Label the y-axis as "Quadrature (Imaginary)" to indicate the imaginary part of the complex symbols.
ylabel('Quadrature (Imaginary)');

% Add a title to the plot describing its purpose.
title(sprintf('Constellation Diagram: Original vs Noisy Received Points (SNR = %.1f dB)', SNR_dB));

% Add a legend to distinguish between the original constellation points and the noisy received symbols.
legend('Location', 'best');

% Enable grid lines for better visualization of the plot.
grid on;

% Ensure equal scaling on both axes to maintain the circular shape of the constellation.
axis equal;

% Limit both axes to [-2, 2]
xlim([-2, 2]);
ylim([-2, 2]);

% Disable hold to prevent further overlays on this figure.
hold off;
