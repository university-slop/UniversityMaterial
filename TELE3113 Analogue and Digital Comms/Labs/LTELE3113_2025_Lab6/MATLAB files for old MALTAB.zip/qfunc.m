% Define Q-function
function y = qfunc(x)
    y = 0.5 * erfc(x / sqrt(2)); % Q(x) = 0.5 * erfc(x / sqrt(2))
end