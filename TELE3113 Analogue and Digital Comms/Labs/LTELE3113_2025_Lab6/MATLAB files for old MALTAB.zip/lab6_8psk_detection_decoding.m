clear all; close all; clc;

%% Parameters
N_data = 120000;  % number of data bits % if channel coding is applied, it must be multiple of bits_per_symbol and bits_per_block
M = 8;
bits_per_symbol = log2(M); % 3 for 8PSK % for an M-ary modulation, bits_per_symbol = log2(M)

bits_per_block = 4; % 4 for Hamming code (7,4) % number of data bits in each block or codeword if we apply channel coding
m = N_data / bits_per_block; % number of blocks or codewords if we apply channel coding
N_encoded = m * 7; % number of encoded bits inclduing data and parity bits
code_rate = 4/7; % for Hamming code (7,4)

%% 8PSK Constellation and Mapping
% Defines the constellation points for an M-ary PSK modulation scheme:
constellation = ...; % Use the one you defined for 8PSK in the other file.
% Assigns Gray-coded binary labels to the constellation points:
bit_labels = [0 0 0; 0 0 1; 0 1 1; 0 1 0; 1 1 0; 1 1 1; 1 0 1; 1 0 0]; 
% Maps the binary input data to decimal values:
symbol_to_index = [1 2 4 3 8 7 5 6];

%% Generating a Random Binary Sequence
data_bits = randi([0 1], 1, N_data);

%% Uncoded Modulation
% The binary data (data_bits) is reshaped into groups of bits_per_symbol
% bits, forming a matrix where each row represents one symbol:
symbol_bits = reshape(data_bits, bits_per_symbol, []).';
% Each row of binary bits is converted to its decimal equivalent using
% positional weighting ([4 2 1] for 3 bits):
weights = repmat([4 2 1], size(symbol_bits, 1), 1);
dec = sum(symbol_bits .* weights, 2);
% The decimal values are mapped to the actual indices of the constellation
% points using the symbol_to_index array:
indices = symbol_to_index(dec + 1);
% The constellation points corresponding to the indices are selected to
% generate the modulated symbols: 
modulated_symbols = constellation(indices);

%% Hamming Encoding - (n,k)=(7,4)
% Generator Matrix G:
G = [1 0 0 0 1 1 0; 0 1 0 0 1 0 1; 0 0 1 0 0 1 1; 0 0 0 1 1 1 1];
% Parity-Check Matrix H:
H = [1 1 0 1 1 0 0; 1 0 1 1 0 1 0; 0 1 1 1 0 0 1];
% The input binary data (data_bits) is reshaped into groups of
% bits_per_block bits, creating a matrix where each row contains one k-bit data block:
data_blocks = reshape(data_bits, bits_per_block, []).';
% Each k-bit data block is multiplied by the generator matrix G to produce
% an n-bit encoded block:
encoded_blocks = mod(data_blocks * G, 2);
% The encoded_blocks matrix is reshaped into a single row vector
% (encoded_bits), concatenating all the encoded bits sequentially:
encoded_bits = reshape(encoded_blocks.', 1, []);
% The encoded bits are grouped into symbols (each consisting of
% bits_per_symbol bits) and mapped to constellation indices for modulation:
symbol_bits_enc = reshape(encoded_bits, bits_per_symbol, []).';
% Each row of symbol_bits_enc is converted to its decimal equivalent using
% positional weighting ([4 2 1] for 3 bits), ie.e, binary to decimal conversion:
weights = repmat([4 2 1], size(symbol_bits_enc, 1), 1);
decimal_enc = sum(symbol_bits_enc .* weights, 2);
% The decimal values are mapped to constellation indices using the
% symbol_to_index array:
indices_enc = symbol_to_index(decimal_enc + 1);
% The indices_enc array is used to select the corresponding constellation
% points from the constellation array. The result is a vector of complex numbers representing the modulated symbols: 
modulated_symbols_enc = constellation(indices_enc);

%% Simulation
SNR_dB = 0:2:12; % Extended range
BER = zeros(size(SNR_dB));
BER_Hamming = zeros(size(SNR_dB));
BER_theoretical = zeros(size(SNR_dB));

for i = 1:length(SNR_dB)
    SNR_linear = 10^(SNR_dB(i) / 10); % Convert to linear scale

    % Uncoded
    sigma = sqrt(1 / SNR_linear);
    noise = (sigma / sqrt(2)) * (randn(size(modulated_symbols)) + 1j * randn(size(modulated_symbols)));
    received = modulated_symbols + noise;
    % Calculate the Euclidean distance between each received
    % symbol and all possible constellation points:
    %distances = abs(received.' - constellation); % for newer versions of     %MATLAB
    distances = abs(repmat(received.', 1, length(constellation)) - repmat(constellation, length(received), 1));
    % Identify the index of the closest constellation point for each
    % received symbol:
    [~, detected_indices] = min(distances, [], 2);
    % Retrieve the binary representation of the detected symbols:
    detected_bits_matrix = bit_labels(detected_indices, :);
    % Reshape the binary data back into a single vector (detected_bits)
    % with the same size as the original transmitted data (data_bits):
    detected_bits = reshape(detected_bits_matrix.', size(data_bits));
    % Calculate the bit error rate (BER) for the current iteration i:
    BER(i) = sum(data_bits ~= detected_bits) / N_data;

    % Theory:
    % Convert Es/N0 to Eb/N0 for 8PSK (k = 3 bits per symbol)
    EbN0_linear = SNR_linear / bits_per_symbol; % Eb/N0 = Es/N0 / k
    BER_theoretical(i) = (1 / bits_per_symbol) * 2 * qfunc(sqrt((6 * EbN0_linear) * sin(pi / M)^2));

    % Coded
    sigma_coded = sqrt(1 / (2 * SNR_linear * code_rate));
    noise = (sigma_coded / sqrt(2)) * (randn(size(modulated_symbols_enc)) + 1j * randn(size(modulated_symbols_enc)));
    received_enc = modulated_symbols_enc + noise;
    %distances = abs(received_enc.' - constellation); % for newer versions of MATLAB
    distances = abs(repmat(received_enc.', 1, length(constellation)) - repmat(constellation, length(received_enc), 1));
    [~, detected_indices] = min(distances, [], 2);
    detected_bits_matrix = bit_labels(detected_indices, :);
    detected_bits_enc = reshape(detected_bits_matrix.', size(encoded_bits));
    % The detected_bits_enc vector is reshaped into groups of n=7 bits, where each group corresponds to one encoded block.
    detected_blocks = reshape(detected_bits_enc, 7, []).';
    decoded_blocks = zeros(m, bits_per_block);
    syndrome_to_pos = [0 7 6 3 5 2 1 4]; % 0-based index: [000]→0, [001]→7, [010]→6, etc.
    % This loop decodes each 7-bit block using the Hamming code, correcting up to one error per block if necessary.
    for k = 1:m
        % Extract the k-th 7-bit block from detected_blocks
        r = detected_blocks(k, :);
        % Computes the syndrome s of the block using the parity-check matrix H.
        s = mod(H * r.', 2);
        % If the syndrome s!=[000], an error is detected.
        if any(s)
            % The syndrome_to_pos array maps the syndrome to the position of the erroneous bit.
            pos = syndrome_to_pos(bin2dec(num2str(s')) + 1); % +1 for 0-based to 1-based
            if pos > 0 && pos <= 7
                % The erroneous bit is flipped to correct the error.
                r(pos) = ~r(pos);
            end
        end
        % After error correction, the first 4 bits of the block (data bits) are extracted and stored in decoded_blocks.
        decoded_blocks(k, :) = r(1:4);
    end
    % The decoded_blocks matrix is reshaped into a single vector (decoded_bits) with the same size as the original transmitted data (data_bits).
    decoded_bits = reshape(decoded_blocks.', size(data_bits));
    BER_Hamming(i) = sum(data_bits ~= decoded_bits) / N_data;
end

%% Results
figure; 
semilogy(SNR_dB, BER, 'b-o', 'LineWidth', 2, 'DisplayName', 'Uncoded (Simulated)');
hold on;
semilogy(SNR_dB, BER_theoretical, 'g-*', 'LineWidth', 2, 'DisplayName', 'Uncoded (Theoretical)');
hold on;
semilogy(SNR_dB, BER_Hamming, 'r-+', 'LineWidth', 2, 'DisplayName', 'Hamming coded');
xlabel('SNR (dB)'); 
ylabel('BER'); 
title('BER vs. SNR for 8PSK Communication System');
legend('show');
grid on;
hold off;
toc; % Stop the timer and display the elapsed time