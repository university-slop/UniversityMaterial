% Clear all variables, close all figures, and clear the command window
clear all; close all; clc;
tic; % Start the timer

%% Parameters
% Define the total number of data bits to be transmitted
N_data = 120000; 

% QPSK Parameters
bits_per_symbol_qpsk = 2; % Number of bits per symbol for QPSK (log2(4) = 2)
constellation_qpsk = ...; % Use the one you developed for the other file.
% Generate QPSK constellation points on the unit circle
bit_labels_qpsk = ...; % % Define an 4x2 matrix that contains the Gray coded label for each point in vector constellation_qpsk
% Assign Gray-coded binary labels to the QPSK constellation points
symbol_to_index_qpsk = ...; % Define a 4-element row vector that contains the the 1-based indeices of rows of bit_labels_qpsk. 
% Map decimal values to indices of the QPSK constellation points

% 8PSK Parameters
%{
bits_per_symbol_8psk = 3; % Number of bits per symbol for 8PSK (log2(8) = 3)
constellation_8psk = ...; You may use the one developed for constellation_qpsk or define another one basedo nthe lab manual.
% Generate 8PSK constellation points on the unit circle
bit_labels_8psk = [0 0 0; 0 0 1; 0 1 1; 0 1 0; 1 1 0; 1 1 1; 1 0 1; 1 0 0]; 
% Assign Gray-coded binary labels to the 8PSK constellation points
symbol_to_index_8psk = [1 2 4 3 8 7 5 6]; 
% Map decimal values to indices of the 8PSK constellation points
%}
%% Generating a Random Binary Sequence
data_bits = randi([0 1], 1, N_data); 
% Generate a random binary sequence of length N_data (0s and 1s)

%% Simulation
SNR_dB = 0:2:12; % Define the range of SNR values in dB (from 0 to 12 dB in steps of 2)
BER_qpsk = zeros(size(SNR_dB)); % Initialize BER array for QPSK
BER_8psk = zeros(size(SNR_dB)); % Initialize BER array for 8PSK
BER_theoretical_qpsk = zeros(size(SNR_dB)); % Initialize theoretical BER array for QPSK
BER_theoretical_8psk = zeros(size(SNR_dB)); % Initialize theoretical BER array for 8PSK

for i = 1:length(SNR_dB) % Loop over each SNR value
    SNR_linear = 10^(SNR_dB(i) / 10); % Convert SNR from dB to linear scale
    
    %% QPSK Modulation and Detection
    % Reshape the binary data into groups of bits_per_symbol_qpsk bits
    symbol_bits_qpsk = reshape(data_bits(1:N_data), bits_per_symbol_qpsk, []).'; 
    % Convert binary groups to decimal values
    % Ensure [2 1] is expanded to match the size of symbol_bits_qpsk
    weights = repmat([2 1], size(symbol_bits_qpsk, 1), 1);
    % Perform element-wise multiplication and sum along rows
    dec_qpsk = sum(symbol_bits_qpsk .* weights, 2);
    %dec_qpsk = sum(symbol_bits_qpsk .* [2 1], 2); 
    % Map decimal values to constellation indices
    indices_qpsk = symbol_to_index_qpsk(dec_qpsk + 1); 
    % Select constellation points based on indices
    modulated_symbols_qpsk = constellation_qpsk(indices_qpsk); 
    
    % Add AWGN noise to the QPSK symbols
    sigma_qpsk = sqrt(1 / SNR_linear); % Compute noise standard deviation
    noise_qpsk = (sigma_qpsk / sqrt(2)) * (randn(size(modulated_symbols_qpsk)) + 1j * randn(size(modulated_symbols_qpsk))); 
    % Generate complex Gaussian noise
    received_qpsk = modulated_symbols_qpsk + noise_qpsk; % Add noise to the transmitted symbols
    
    % Detect symbols using minimum Euclidean distance
    %distances_qpsk = abs(received_qpsk.' - constellation_qpsk); % for newer versions of MATLAB
    distances_qpsk = abs(repmat(received_qpsk.', 1, length(constellation_qpsk)) - repmat(constellation_qpsk, length(received_qpsk), 1));
    % Compute distances between received symbols and constellation points
    [~, detected_indices_qpsk] = min(distances_qpsk, [], 2); 
    % Find the index of the closest constellation point
    detected_bits_matrix_qpsk = bit_labels_qpsk(detected_indices_qpsk, :); 
    % Retrieve the binary representation of the detected symbols
    detected_bits_qpsk = reshape(detected_bits_matrix_qpsk.', size(data_bits(1:N_data))); 
    % Reshape the detected bits into a single vector
    BER_qpsk(i) = sum(data_bits(1:N_data) ~= detected_bits_qpsk) / N_data; 
    % Calculate the BER for QPSK
    
    % Compute theoretical BER for QPSK
    EbN0_linear_qpsk = SNR_linear / bits_per_symbol_qpsk; % Convert Es/N0 to Eb/N0
    BER_theoretical_qpsk(i) = qfunc(sqrt(2 * EbN0_linear_qpsk)); 

    %{
    %% 8PSK Modulation and Detection
    % Reshape the binary data into groups of bits_per_symbol_8psk bits
    symbol_bits_8psk = reshape(data_bits(1:N_data), bits_per_symbol_8psk, []).'; 
    % Convert binary groups to decimal values
    % Ensure [4 2 1] is expanded to match the size of symbol_bits_qpsk
    weights = repmat([4 2 1], size(symbol_bits_8psk, 1), 1);
    % Perform element-wise multiplication and sum along rows
    dec_8psk = sum(symbol_bits_8psk .* weights, 2);
    %dec_8psk = sum(symbol_bits_8psk .* [4 2 1], 2); 
    % Map decimal values to constellation indices
    indices_8psk = symbol_to_index_8psk(dec_8psk + 1); 
    % Select constellation points based on indices
    modulated_symbols_8psk = constellation_8psk(indices_8psk); 
    
    % Add AWGN noise to the 8PSK symbols
    sigma_8psk = sqrt(1 / SNR_linear); % Compute noise standard deviation
    noise_8psk = (sigma_8psk / sqrt(2)) * (randn(size(modulated_symbols_8psk)) + 1j * randn(size(modulated_symbols_8psk))); 
    % Generate complex Gaussian noise
    received_8psk = modulated_symbols_8psk + noise_8psk; % Add noise to the transmitted symbols
    
    % Detect symbols using minimum Euclidean distance %%%%%%%%%%%%%%%%%
    %distances_8psk = abs(received_8psk.' - constellation_8psk); 
    distances_8psk = abs(repmat(received_8psk.', 1, length(constellation_8psk)) - repmat(constellation_8psk, length(received_8psk), 1));
    % Compute distances between received symbols and constellation points
    [~, detected_indices_8psk] = min(distances_8psk, [], 2); 
    % Find the index of the closest constellation point
    detected_bits_matrix_8psk = bit_labels_8psk(detected_indices_8psk, :); 
    % Retrieve the binary representation of the detected symbols
    detected_bits_8psk = reshape(detected_bits_matrix_8psk.', size(data_bits(1:N_data))); 
    % Reshape the detected bits into a single vector
    BER_8psk(i) = sum(data_bits(1:N_data) ~= detected_bits_8psk) / N_data; 
    % Calculate the BER for 8PSK
    
    % Compute theoretical BER for 8PSK
    EbN0_linear_8psk = SNR_linear / bits_per_symbol_8psk; % Convert Es/N0 to Eb/N0
    BER_theoretical_8psk(i) = (1 / bits_per_symbol_8psk) * 2 * qfunc(sqrt((6 * EbN0_linear_8psk) * sin(pi / 8)^2)); 
    %}
end

%% Results
figure; 
semilogy(SNR_dB, BER_qpsk, 'b-o', 'LineWidth', 2, 'DisplayName', 'QPSK Simulated'); 
% Plot QPSK simulated BER curve
hold on;
semilogy(SNR_dB, BER_theoretical_qpsk, 'b--', 'LineWidth', 2, 'DisplayName', 'QPSK Theoretical'); 
% Plot QPSK theoretical BER curve
%{
semilogy(SNR_dB, BER_8psk, 'r-+', 'LineWidth', 2, 'DisplayName', '8PSK Simulated'); 
% Plot 8PSK simulated BER curve
semilogy(SNR_dB, BER_theoretical_8psk, 'r--', 'LineWidth', 2, 'DisplayName', '8PSK Theoretical'); 
% Plot 8PSK theoretical BER curve
%}
xlabel('SNR (dB)'); % Label the x-axis as SNR in dB
ylabel('BER'); % Label the y-axis as Bit Error Rate (BER)
title('BER vs. SNR for QPSK and 8PSK Communication Systems'); % Add a title to the plot
legend('show'); % Display the legend
grid on; % Enable grid lines for better readability
hold off; % Disable hold to prevent further overlays

disp('BER at SNR = 10 dB:'); % Display BER values at SNR = 10 dB
disp(['QPSK Simulated: ', num2str(BER_qpsk(6))]); % Display QPSK simulated BER
disp(['8PSK Simulated: ', num2str(BER_8psk(6))]); % Display 8PSK simulated BER

toc; % Stop the timer and display the elapsed time